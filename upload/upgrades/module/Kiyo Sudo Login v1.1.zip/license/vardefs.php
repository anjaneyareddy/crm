<?php 
$vardefs = array (
  'fields' => 
  array (
  ),
  'relationships' => 
  array (
  ),
);