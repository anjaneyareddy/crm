<?php
$mod_strings['LBL_SUDOLOGIN_LOGIN_AS'] = 'Sudo Login as';