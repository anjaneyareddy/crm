<?php
    $action_view_map['sudologin_disconnect'] = 'sudologin_disconnect';
    $action_view_map['sudologin_connect'] = 'sudologin_connect';
