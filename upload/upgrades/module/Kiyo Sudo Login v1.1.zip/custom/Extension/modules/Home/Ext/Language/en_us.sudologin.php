<?php
$mod_strings['LBL_SUDOLOGIN_LOGOUT_AS'] = 'Disconnect as';
$mod_strings['LBL_SUDOLOGIN_LOGIN_AS'] = 'Sudo Login...';
$mod_strings['LBL_SUDOLOGIN_POPUP_TITLE'] = 'Sudo Login';
$mod_strings['LBL_SUDOLOGIN_POPUP_SUBTITLE'] = 'Log in as another user';
$mod_strings['LBL_SUDOLOGIN_POPUP_BLOCKQUOTE'] = 'Great power comes great responsibility';
$mod_strings['LBL_SUDOLOGIN_POPUP_P1'] = 'Please, use Sudo Login <b>wisely</b>, you will be connected as the selected user.';
$mod_strings['LBL_SUDOLOGIN_POPUP_P2'] = 'Also note that the user will <b>not</b> be signed off during your session.';
$mod_strings['LBL_SUDOLOGIN_POPUP_P3'] = 'SudoLogin will only enable you to connect as <b>Regular</b> (not Admin) and <b>Active</b> User.';
$mod_strings['LBL_SUDOLOGIN_POPUP_P4'] = 'Select the desired user in the list below :';
$mod_strings['LBL_SUDOLOGIN_SELECT_HINT'] = 'Choose a user';
