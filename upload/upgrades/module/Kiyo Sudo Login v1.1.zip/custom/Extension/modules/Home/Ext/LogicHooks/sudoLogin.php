<?php

$hook_version = 1;

$hook_array['after_ui_frame'][] = array(
    '100', 
    'Create JS Menu Popup to select a user to log as',
    'custom/modules/Home/SudoLoginConnectAsMenuHook.php',
    'SudoLoginConnectAsMenuHook',
    'aui_sudologin_menuconnectas', 
);
