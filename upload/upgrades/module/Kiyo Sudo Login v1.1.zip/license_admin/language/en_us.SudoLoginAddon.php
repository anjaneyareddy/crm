<?php

$mod_strings['LBL_SUDOLOGINADDON'] = 'Sudo Login Add-on';