# Sudo Login Plugin for KiyoCRM
This plugin will allow Administrators to quickly switch accross KiyoCRM Users without knowing their password.
 