<?php

$mod_strings['LBL_TIME_LEFT'] = "Time left";
$mod_strings['LBL_RESEND_OTP'] = "Resend OTP";
$mod_strings['LBL_CONTINUE'] = "Continue";
$mod_strings['LBL_OTP_EXPIRED'] = "This OTP is Expired.";
$mod_strings['LBL_VALID_USER'] = "Please add valid user for login security";
$mod_strings['LBL_DENIED_IP_ADDRESS'] = "This IP Address has Denied Login to KiyoCRM";
$mod_strings['LBL_WRONG_OTP'] = "You have entered wrong OTP.";
$mod_strings['LBL_VALID_OTP'] = "Please enter Valid OTP";
$mod_strings['LBL_VALID_CREDENTIALS'] = "Please Enter Valid User Credentials";
$mod_strings['LBL_SUPER_CHARGED_KIYOCRM'] = "Supercharged by KiyoCRM";
$mod_strings['LBL_POWERED_SUGARCRM'] = "Powered By SugarCRM";
$mod_strings['LBL_KIYOCRM'] = "KiyoCRM";
$mod_strings['LBL_VALID_EMAIL_ADDRESS'] = "User does not have the Email Address. Please ask Administrator to enter the Email Address in User Profile for receive the OTP to Authenticate";
$mod_strings['LBL_VALID_LOGIN_CREDENTIALS'] = "Please add valid user for login.";
