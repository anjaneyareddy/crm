<?php

$action_view_map['loginsecurityconfig'] = 'loginsecurityconfig';
$action_view_map['loginsecuritylistview'] = 'loginsecuritylistview';
